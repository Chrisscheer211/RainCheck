package edu.farmingdale.alrajab.weather

import android.os.AsyncTask
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.URL
import java.util.*
import android.content.Context
import android.icu.util.TimeZone.GMT_ZONE
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import kotlinx.android.synthetic.*


class MainActivity : AppCompatActivity() {
    lateinit var location: EditText
    lateinit var update: Button
    lateinit var cancel: Button
    var city: String = "New York"
    val key: String = "af2b0e768df989c01f51e780365ff8d3"
    lateinit var iconView : ImageView
    lateinit var clock : TextClock



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        location = findViewById(R.id.editTxt1)
        update = findViewById(R.id.updateBtn)
        cancel = findViewById(R.id.cancelBtn)
        iconView = findViewById(R.id.weather_icon)
        clock = findViewById(R.id.clock)


        location.setOnClickListener {
            findViewById<Button>(R.id.updateBtn).visibility = View.VISIBLE
            findViewById<Button>(R.id.cancelBtn).visibility = View.VISIBLE

            update.setOnClickListener {
                city = location.getText().toString()
                findViewById<Button>(R.id.updateBtn).visibility = View.GONE
                findViewById<Button>(R.id.cancelBtn).visibility = View.GONE
                location.setCursorVisible(false)
                weatherTask().execute()
            }
           cancel.setOnClickListener {
               location.setText(city)
               findViewById<Button>(R.id.updateBtn).visibility = View.GONE
               findViewById<Button>(R.id.cancelBtn).visibility = View.GONE
               location.setCursorVisible(false)
           }
        }

        weatherTask().execute()

    }

    inner class weatherTask() : AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg p0: String?): String? {
         var response : String?
         try {
             response = URL("https://api.openweathermap.org/data/2.5/weather?q=$city&units=imperial&appid=af2b0e768df989c01f51e780365ff8d3")
                 .readText(Charsets.UTF_8)
         }
         catch(e: Exception){
             response = null
         }
            return response
        }

        override fun onPostExecute(result: String?) {

            super.onPostExecute(result)
            try{
                val jsonObj = JSONObject(result)
                val main = jsonObj.getJSONObject("main")
                val sys = jsonObj.getJSONObject("sys")
                val weather = jsonObj.getJSONArray("weather").getJSONObject(0)
                val temp = main.getString("temp") +"°F"
                val tempMin = "Min Temp: " + main.getString("temp_min")+"°F"
                val tempMax = "Max Temp: " + main.getString("temp_max")+"°F"
                val feel = "Feels like: " + main.getString("feels_like")
                val icon = weather.getString("icon")
                val weatherDescription = weather.getString("description")


                findViewById<TextView>(R.id.weather_desc).text = weatherDescription
                findViewById<TextView>(R.id.main_temp).text = temp
                findViewById<TextView>(R.id.min_temp).text = tempMin
                findViewById<TextView>(R.id.max_temp).text = tempMax
                findViewById<TextView>(R.id.feels_like).text = feel



                when(icon.toString()){
                    "01d"-> iconView.setImageResource(R.drawable.clearsky)
                    "01n"-> iconView.setImageResource(R.drawable.clearskysnight)
                    "02d"-> iconView.setImageResource(R.drawable.fewclouds)
                    "02n"-> iconView.setImageResource(R.drawable.fewcloudsnight)
                    "03d"-> iconView.setImageResource(R.drawable.scatteredclouds)
                    "03n"-> iconView.setImageResource(R.drawable.scatteredclouds)
                    "04d"-> iconView.setImageResource(R.drawable.brokenclouds)
                    "04n"-> iconView.setImageResource(R.drawable.brokenclouds)
                    "09d"-> iconView.setImageResource(R.drawable.showerrain)
                    "09n"-> iconView.setImageResource(R.drawable.showerrain)
                    "10d"-> iconView.setImageResource(R.drawable.rain)
                    "10n"-> iconView.setImageResource(R.drawable.rainnight)
                    "11d"-> iconView.setImageResource(R.drawable.thunderstorm)
                    "11n"-> iconView.setImageResource(R.drawable.thunderstorm)
                    "13d"-> iconView.setImageResource(R.drawable.snow)
                    "13n"-> iconView.setImageResource(R.drawable.snow)
                    "50d"-> iconView.setImageResource(R.drawable.mist)
                    "50n"->iconView.setImageResource(R.drawable.mist)
                }
            }
            catch(e:Exception){
               findViewById<LinearLayout>(R.id.linear2).visibility = View.GONE
            }
        }
    }
}

